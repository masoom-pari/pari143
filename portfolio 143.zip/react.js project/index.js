//alert("hello pari");
//console.log("pari");

// alert("pari");
// alert("pari");
// alert(pari);

scroll-top-

const heroSection = document.querySelector(".section-hero");

const footerElem = document.querySelector(".footer-sec");

const scroollElement = document.createElement("div");
scroollElement.classList.add("scrollTop-style");

scroollElement.innerHTML = '<ion-icon name="arrow-up-outline" class="scroll-top"></ion-icon>';

footerElem.after(scroollElement);

const scrollTop = () => {
   heroSection.scrollIntoView({behavior: "smooth"});

};

test.addEventListerner("mouseOver", setDark);
test.addEventListerner("mouseOut", setLight);

function setDark() {
   document.body.style.background = "green";
   test.style.color ="white";
}

function setLight() {
    document.body.style.background ="brown";
   test.style.color="white";
}
//scroollElement.addEventListener("click", scrollTop);

//<div class="lw-widget-in learnworlds-main-text learnworlds-element learnworlds-main-text-large none" data-element-id="typed2" data-node-type="typed" id="el_1697995591336_615">Alpha - DSA | Delta - Web Development | Sigma - DSA + Web Development | C++ DSA</div>

 console.log("hello");
 alert("pari")
