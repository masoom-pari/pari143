# # Function for addition
# def add(x, y):
#     return x + y

# # Function for subtraction
# def subtract(x, y):
#     return x - y

# # Function for multiplication
# def multiply(x, y):
#     return x * y

# # Function for division
# def divide(x, y):
#     if y != 0:  # Check to avoid division by zero
#         return x / y
#     else:
#         return "Error! Division by zero."
# # Displaying the menu to the user
# print("Select operation:")
# print("1. Add")
# print("2. Subtract")
# print("3. Multiply")
# print("4. Divide")

# # Taking user input for operation
# choice = input("Enter choice (1/2/3/4): ")
# # Taking the numbers as input from the user
# num1 = float(input("Enter first number: "))
# num2 = float(input("Enter second number: "))

# # Performing the calculation based on user choice
# if choice == '1':
#     print(f"{num1} + {num2} = {add(num1, num2)}")
# elif choice == '2':
#     print(f"{num1} - {num2} = {subtract(num1, num2)}")
# elif choice == '3':
#     print(f"{num1} * {num2} = {multiply(num1, num2)}")
# elif choice == '4':
#     print(f"{num1} / {num2} = {divide(num1, num2)}")
# else:
#     print("Invalid input")


# # Functions for operations
# def add(x, y):
#     return x + y

# def subtract(x, y):
#     return x - y

# def multiply(x, y):
#     return x * y

# def divide(x, y):
#     if y != 0:  # Avoid division by zero
#         return x / y
#     else:
#         return "Error! Division by zero."

# # Main program
# print("Select operation:")
# print("1. Add")
# print("2. Subtract")
# print("3. Multiply")
# print("4. Divide")

# # Taking user input for operation
# choice = input("Enter choice (1/2/3/4): ")

# # Taking the numbers as input from the user
# num1 = float(input("Enter first number: "))
# num2 = float(input("Enter second number: "))

# # Performing the calculation
# if choice == '1':
#     print(f"{num1} + {num2} = {add(num1, num2)}")
# elif choice == '2':
#     print(f"{num1} - {num2} = {subtract(num1, num2)}")
# elif choice == '3':
#     print(f"{num1} * {num2} = {multiply(num1, num2)}")
# elif choice == '4':
#     print(f"{num1} / {num2} = {divide(num1, num2)}")
# else:
#     print("Invalid input")


# # Functions for operations
# def add(x, y):
#     return x + y

# def subtract(x, y):
#     return x - y

# def multiply(x, y):
#     return x * y

# def divide(x, y):
#     if y != 0:  # Avoid division by zero
#         return x / y
#     else:
#         return "Error! Division by zero."

# # Main program
# print("Select operation:")
# print("1. Add")
# print("2. Subtract")
# print("3. Multiply")
# print("4. Divide")

# # Taking user input for operation
# choice = input("Enter choice (1/2/3/4): ")

# # Taking the numbers as input from the user
# num1 = float(input("Enter first number: "))
# num2 = float(input("Enter second number: "))

# # Performing the calculation
# if choice == '1':
#     print(f"{num1} + {num2} = {add(num1, num2)}")
# elif choice == '2':
#     print(f"{num1} - {num2} = {subtract(num1, num2)}")
# elif choice == '3':
#     print(f"{num1} * {num2} = {multiply(num1, num2)}")
# elif choice == '4':
#     print(f"{num1} / {num2} = {divide(num1, num2)}")
# else:
#     print("Invalid input")


# step 6

# To decide which ticket is better for you, let's break down the situation:

# - **You have 100 rupees** in your wallet.
# - You have two options:
#   - **Option 1**: A ticket that costs **80 rupees**.
#   - **Option 2**: A ticket that costs **120 rupees**.

# Now, let's consider the following:

# ### 1. **Budget Consideration**:
# - If you choose the **80 rupees ticket**, you will spend **80 rupees** and will still have **20 rupees left** in your wallet. This means you will have some money remaining after purchasing the ticket.
  
# - If you choose the **120 rupees ticket**, you will be short of **20 rupees** because you only have **100 rupees**, and the ticket costs **120 rupees**. This would require you to either borrow or find an additional 20 rupees, which could be inconvenient.

# ### 2. **Value and Benefits**:
# To determine which ticket is "better," you need to consider what the tickets offer. If the **120 rupees ticket** gives you more value (such as better seats, a more desirable event, etc.), it might be worth stretching your budget and finding the extra 20 rupees.

# However, if both tickets offer similar value and you are looking to stick to your **budget** without additional stress, the **80 rupees ticket** is the safer choice since it allows you to keep within your available funds.

# ### Conclusion:
# - If you're **okay with stretching your budget** or can find the additional 20 rupees, the **120 rupees ticket** might offer more value (depending on what it offers).
# - If you'd prefer to **stay within your budget** without the need to borrow money, the **80 rupees ticket** is the better choice for now since it will leave you with money left over.

# Would you like help comparing the value of both tickets (e.g., their benefits or features), or do you already have that information?2+

class MenuItem:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def __str__(self):
        return f"{self.name}: ${self.price:.2f}"

class Restaurant:
    def __init__(self, name):
        self.name = name
        self.menu = []
        self.orders = []

    def add_menu_item(self, item):
        self.menu.append(item)

    def display_menu(self):
        print(f"\n--- {self.name} Menu ---")
        for i, item in enumerate(self.menu):
            print(f"{i + 1}. {item}")

    def take_order(self):
        self.display_menu()
        order = []
        while True:
            try:
                choice = int(input("Enter item number (0 to finish): "))
                if choice == 0:
                    break
                item = self.menu[choice - 1]
                order.append(item)
            except (ValueError, IndexError):
                print("Invalid input.")
        self.orders.append(order)
        print("Order placed!")

    def display_orders(self):
        print("\n--- Current Orders ---")
        for i, order in enumerate(self.orders):
            print(f"Order {i + 1}:")
            total = 0
            for item in order:
                print(f"  - {item}")
                total += item.price
            print(f"  Total: ${total:.2f}")

# Example usage
restaurant = Restaurant("My Python Diner")
restaurant.add_menu_item(MenuItem("Burger", 8.99))
restaurant.add_menu_item(MenuItem("Pizza", 12.50))
restaurant.add_menu_item(MenuItem("Salad", 6.75))

while True:
    print("\n1. View Menu")
    print("2. Place Order")
    print("3. View Orders")
    print("4. Exit")
    choice = input("Enter choice: ")

    if choice == "1":
        restaurant.display_menu()
    elif choice == "2":
        restaurant.take_order()
    elif choice == "3":
        restaurant.display_orders()
    elif choice == "4":
        break
    else:
        print("Invalid choice.")