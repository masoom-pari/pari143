@media only screen and (max-width:3200px) and (min-width: 1240) {
    .navbar {
        max-width:auto
    }
}

@media only screen and (max-width:1200px) and (min-width: 940) {
    .navbar {
        max-width:auto
    }

    *body {
        font-size:15px
    }
    .navbar-lists {
        font-size:0.1rem
        font-weight:200
        gap:1rem
    }
    .hero-img {
        position:fixed
        top:0
    }
}