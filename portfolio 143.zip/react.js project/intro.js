const footerElem = document.queryselector(".s-footer");

    const scroollElem = document.createElement("div");
    scroollElement.classlist.add("scrolTop-style");

    scroolElement.innerHTML = ""


//let charName="pari"
//let pswrd = "143"
//console.log(charName);
//console.log(typeof charName);
//console.log(len charName);
//console.log(pswrd);


//alert
// alert("WELCOME PARI WEBSITE");


 //while loop

//let emailName = "email";
//let userName = prompt("enter the emailName :");
//while(userName != emailName) {
    //console.log("you enter the wrong number");
 //}
   // console.log("cong, u entered the right num");

    //prompt

//let myNum = "25"
//let userNum = prompt("enter num :");
//while(userNum != myNum) {
   // console.log("you enter the wrong number");
//}
   // console.log("cong, u entered the right num");

    //boolen
   // let aP = 25;
    //if(aP) {
       // console.log("true");
   // } else {
       // console.log("false");
   // }


 var swiper = new Swiper(".mySwiper", {
        slidesPerView: 2,
        spaceBetween: 30,
        autoplay: {
            delay: 2500S,
            disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
 });

    //inline element

<button onclick="alert('welcome, pari darling')">pari x</button>

    //internal

<script>
        alert("pari");
        console.log("pariy")
 </script>

   //external element

//<script src=".js"></script>

   //concatenation

   //const str = "hello" + "pari"
  // console.log(str)

   //type coercion   1. implicit  2. explicit


  // const personS = ["PARI"];
  // const personS = ["jhon"];
   //const personS = ["PARI", "jhon", "jack"]; // infinity name in 1way not repeat

  // Array.length -1  //- = last num -1

   //person[0] //pari{lower index or lowr boundry=o indx / upper index = -2}
  // person.length 

 //  person . at[-1]  //last count with strts -1 -2 -3


   // CALUCLATOR

   //console.log(caluclator(5, 2, "+"))   // =7

   //or  if stmt or switch stmt -2ways

   //function calculator(num1, num2, operator){
   // let result;
   // if(operator == "+")
  //    5+2;
  // }   //repeat evry time time takn

   //switch stmt

   //function caluclator(num1, num2, operator) {
    //let result;
    ////switch (operator) {
       //// case "+";
       // result num1 + num2;
//      return result;

        //ex

      //  case "-";
        //result = num1 -num2;
        //return result;

      //  case "/":
      ////      if (num2 == 0) {
     //           return '0 is nt allowed';
//} else {
          //      result num1 / num2;
         //       return result;
         //   }

       // default:
       ////     return 'no operatot found';
   // }

    } 

      //arry methods

     // let sNum = ["np mp"];
      //let gNum = ["food", lood]
      //sNum.push("as"); //add in end
    //  sNum.pop("as"); //delt in end
     // sNum.unshift("as"); //add in first
     // sNum.shift("as"); //delt in first
     // sNum.to string("as"); //convrt string into arry
     // console.log(sNum.tostring);

      //concat
     // sNum.concat(gNum); // ["np" , "mp", "food" , "lodd"]

      //slice orginl ary nt chng

    //  console.log(sNum.slice[1,2]) //1 delt 

      //splice originl ary chng   3items 1start ,delt,newelm
     // console.log(sNum.splice[1, 2 101,102])
     // Array.splice(2, 2, 102);

      //functions

     // function mynam() {
     //   console.log("paru");
     // }















